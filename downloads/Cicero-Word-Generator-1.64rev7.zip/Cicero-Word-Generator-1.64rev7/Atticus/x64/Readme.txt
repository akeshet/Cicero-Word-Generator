This is Atticus Hardware Server (x64 version), part of the Cicero Word Generator control software suite for atomic physics experiments.

For more information, see http://akeshet.github.com/Cicero-Word-Generator/