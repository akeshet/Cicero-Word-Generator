This is Atticus Hardware Server (x86 version), part of the Cicero Word Generator control software suite for atomic physics experiments.

For more information, see http://akeshet.github.com/Cicero-Word-Generator/