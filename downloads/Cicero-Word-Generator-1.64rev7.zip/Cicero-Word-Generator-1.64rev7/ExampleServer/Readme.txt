This is Virgil Example Server, part of the Cicero Word Generator control software suite for atomic physics experiments.

For more information, see http://akeshet.github.com/Cicero-Word-Generator/